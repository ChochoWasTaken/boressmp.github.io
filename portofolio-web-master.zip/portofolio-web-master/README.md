# Website Portfolio Pribadi

Project ini digunakan untuk membuat website portofolio pribadi menggunakan [template portofolio bootstrap free](https://startbootstrap.com/template-overviews/creative/)

## Cara menggunakan :
1. `git clone https://github.com/puguhsudarma/portofolio-web.git`
2. `npm install`
3. `npm start`